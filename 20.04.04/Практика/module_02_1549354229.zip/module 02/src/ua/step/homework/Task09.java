package ua.step.homework;
/*
 * Шаблон для решения домашнеего задания 9. 
 */
/**
 * Проверить, имеет ли число в переменной типа float вещественную часть.
 * Например, числа 3.14 и 2.5 – имеют вещественную часть, а числа 5.0 и 10.0 – нет.
 */
public class Task09
{
    public static void main(String[] args)
    {
        final float testFloat = 3.14f;
    }
}
