package ua.step.puzzle;

public class Tweedledum
{
    public static void main(String[] args)
    {
        // Вставте в код инициализацию переменных x и i таким образом чтобы,
        // одновременно выполнялись два условие

        // x += i; // должно компилироваться
        // x = x + i; // не должно компилироваться
        // System.out.println(x);
    }
}
