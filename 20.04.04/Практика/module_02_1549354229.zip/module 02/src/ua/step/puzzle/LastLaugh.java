package ua.step.puzzle;

/**
 * Хорошо смеется тот...
 *  
 */
public class LastLaugh {
    public static void main(String args[]) {
        System.out.print("H" + "a");
        System.out.print('H' + 'a');
        //FIXME объясни почем этот код не выводит HaHa 
    }
}
