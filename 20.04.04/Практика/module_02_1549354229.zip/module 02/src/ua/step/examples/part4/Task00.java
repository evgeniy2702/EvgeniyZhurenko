package ua.step.examples.part4;

/**
 * Переменные логических типов
 * 
 */
public class Task00
{
    public static void main(String[] args)
    {
        // true это литерал - одно из значений перемнной с типом boolean
        // обозначающее "истину"
        boolean b1 = true;
        System.out.println(b1);
        
        b1 = false; // false обозначает "ложь"
        System.out.println(b1);
    }
}