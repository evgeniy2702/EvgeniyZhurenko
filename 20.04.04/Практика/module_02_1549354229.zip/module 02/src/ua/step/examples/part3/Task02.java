package ua.step.examples.part3;

/**
 * Статические методы класса Character 
 */
public class Task02
{
    public static void main(String[] args)
    {
        char a = 'A';
        char b = '1';
        System.out.println(Character.toLowerCase(a));
        System.out.println(Character.isDigit(b));
    }
}