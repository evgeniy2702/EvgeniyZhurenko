package ua.step.examples.part2;

/**
 * Переменные дробных типов
 * 
 */
public class Task01
{
    public static void main(String[] args)
    {
        double x = 2;
        double y = 1.9;
        System.out.println(x - y);
    }
}