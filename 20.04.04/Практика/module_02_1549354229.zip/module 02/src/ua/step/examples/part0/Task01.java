package ua.step.examples.part0;

/**
 * 
 * Первая программа на java HelloWorld
 * Нажми белый треугольник в зеленом кружке для выполнения кода.
 * Результат смотри в View с названием Console
 *
 */
public class Task01
{
    //FIXME разкоментируйте строки, с которыми код скомпилируется и выполниться.
    public static void main(String[] args) 
    {  
    	System.out.println("Hello world!"); // Команда вывода информации в консоль
        //System.out.println(Hello world!);
        //System.out.println("Hello world!")
    	//FIXME Выведи строку Hello world! три раза, каждый раз в новой строке 
    } 
    //System.out.println("Hello world!!!");
}
//System.out.println("Hello world!!!!");