package ua.step.examples.part3;

/**
 * Сложение символьных типов
 */
public class Task01
{
    public static void main(String[] args)
    {
        char a = 'A'; 
        char b = 3;
        // сложение символьных типов дает результат типа int
        System.out.println(a + b);
    }
}