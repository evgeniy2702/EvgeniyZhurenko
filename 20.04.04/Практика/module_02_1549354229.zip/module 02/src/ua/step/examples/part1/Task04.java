package ua.step.examples.part1;

/**
 * Регистр букв и не только.  
 * 
 */
public class Task04
{
     public static void main(String[] args)
    {
       // регистр в названии переменных имеет значение
        int A = 2;
        int a = 1;
        int а = 3; // не только регистр имеет значение
        System.out.println(A);
        System.out.println(a);
        System.out.println(а);
    }
}