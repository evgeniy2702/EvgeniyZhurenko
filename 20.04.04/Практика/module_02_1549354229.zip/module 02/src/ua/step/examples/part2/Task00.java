package ua.step.examples.part2;

/**
 * Переменные дробных типов
 * 
 */
public class Task00
{
    public static void main(String[] args)
    {
    	float x = 0.7f; 
    	System.out.println(x);
    	
    	double y = 0.1;
    	System.out.println(y);
    	// FIXME Выведи в консоль сумму значений переменных x и y
    }
}